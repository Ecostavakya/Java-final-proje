package Models;

public class Ogrenci {
    public String OgrenciAdi;
    public String OgrenciSoyadi;
    public String OgrenciNo;

    public String OgrenciDers;

}

