package Models;

public class OgretimGorevlisi {
    public static String OgretmenAd;
    public static String OgretmenSoyad;
    public static String OgretmenNo;
    public static String OgretmenDers;
}
