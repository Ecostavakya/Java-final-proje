package Models;


public class Ders {
    public String DersKodu;
    public String DersIsmi;

    public  String DersFakülte;
    public  String DersDepartman;
}
